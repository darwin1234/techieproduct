## Supported Platforms

### Version 1.9.x

- Cordova CLI (6.4.0 or newer)
- Android (`cordova-android` 6.0.0 or higher)
- Browser
- iOS (`cordova-ios` 4.3.0 or higher)
- Windows Universal (not Windows Phone 8)

### Version 1.8.x

- Cordova CLI (3.6.3 or newer)
- Android (`cordova-android` 4.0.0 or higher)
- Browser
- iOS (`cordova-ios` 4.1.0 or higher)
- Windows Universal (not Windows Phone 8)
